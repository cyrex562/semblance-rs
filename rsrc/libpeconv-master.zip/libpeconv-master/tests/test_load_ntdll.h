#pragma once

#include "peconv.h"

namespace tests {

    //For now this is for manual tests only:
    int test_ntdll(char *path);

}; //namespace tests