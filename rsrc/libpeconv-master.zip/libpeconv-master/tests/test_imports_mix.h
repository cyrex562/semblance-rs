#pragma once

#include <peconv.h>

namespace tests {

    int imports_mix(const char *my_path);

}; //namespace tests
