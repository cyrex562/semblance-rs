# FlareOn2017 Challenge 6

### Writeup

+   [Solving Flare-On 2017, Challenge 6 with libPeConv](https://hshrzd.wordpress.com/2017/12/01/hook-the-planet-solving-flareon4-challenge6-with-libpeconv/)
