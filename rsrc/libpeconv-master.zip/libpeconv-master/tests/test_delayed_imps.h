#pragma once

#include "peconv.h"

namespace tests {

    int replace_delayed_imps(char *path);

}; //namespace tests
