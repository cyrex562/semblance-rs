#pragma once

#include "peconv.h"

namespace tests {

    int decode_crackme_f4_6(char *path);

}; //namespace tests