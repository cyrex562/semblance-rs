#pragma once

#include <peconv.h>

namespace tests {

    int check_finding_jumps();

}; //namespace tests
