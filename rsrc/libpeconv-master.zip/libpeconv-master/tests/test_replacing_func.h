#pragma once

#include "peconv.h"

namespace tests {

    int replace_func_testcase(char *path);

}; //namespace tests
