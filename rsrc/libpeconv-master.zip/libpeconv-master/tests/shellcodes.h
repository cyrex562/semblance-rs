#pragma once

#include "shellc32.h"
#include "shellc64.h"
