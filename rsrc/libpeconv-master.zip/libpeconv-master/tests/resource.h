// resource.h

#define CRACKME_F4_3_32	101
