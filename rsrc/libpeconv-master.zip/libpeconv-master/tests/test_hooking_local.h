#pragma once

#include <peconv.h>

namespace tests {

    int hook_self_local();

}; //namespace tests
