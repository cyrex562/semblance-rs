#pragma once

#include <peconv.h>

namespace tests {

    int check_modules();

}; //namespace tests
