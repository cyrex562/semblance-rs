#pragma once

namespace tests {

    int load_and_check_base(const char *path);

}; //namespace tests
