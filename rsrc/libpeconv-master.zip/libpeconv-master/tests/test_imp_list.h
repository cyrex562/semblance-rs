#pragma once

#include <peconv.h>

namespace tests {

    int imp_list(char *path);

}; //namespace tests
