#pragma once

#include "peconv.h"

namespace tests {

int load_self();

}; //namespace tests
