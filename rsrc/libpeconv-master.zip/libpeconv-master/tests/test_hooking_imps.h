#pragma once

#include "peconv.h"

namespace tests {

    int hook_testcase(char *path);

}; //namespace tests
