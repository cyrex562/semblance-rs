## PeLib

This repository is no longer alive. Its sources were moved directly to the main RetDec [repository](https://github.com/avast/retdec). It will be removed altogether after some transitional period.
