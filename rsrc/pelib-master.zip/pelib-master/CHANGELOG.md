# Changelog

# dev

* Rewrite for C++17.
* Removed functionality concerning re-building of relocations due to its flaws
  ([#15](https://github.com/avast/pelib/issues/15),
  [#16](https://github.com/avast/pelib/pull/16)).
* Fixed detection of cut import directory
  ([#17](https://github.com/avast/pelib/pull/17)).

# v1.0 (2017-12-12)

Initial release.
